Пакет настроек по умолчанию для MODX Revolution.
Created by: Dmitry Tanzirev
WWW: tanzirev.ru